package com.example.health_monitor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
