import 'package:flutter_app1/HomeScreen.dart';
//import 'package:flutter_app1/PizzaApp.dart';
import 'package:flutter/material.dart';

void main() {
  // WidgetsFlutterBinding.ensureInitialized();
  //  Firebase.initializeApp();

  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      // home: HomeScreen(),
      // home: BottomNavigationDemo(),
      // home: MyTabBar(),
      // home: MyTabBar1(),
      // home: DrawerDemo(),
      // home: ListTileDemo(),
      // home: DataTableDemo(),
      // home: SelectableDemo(),
      // home: TextFieldDemo(),
      // home: sicalci(),
      // home: PizzaApp(),
      // Day-23
      // home: AnimateWidget(),
      // home: WebViewDemo(),
      // home: BottomSheetDemo(),
      // home: StackDemo(),
      //home: PizzaApp(),
      home: HomeScreen(),
      // home: Drawer(),

      // routes: {
      //   'S0': (context) => Screen0(title: "Settings"),
      //   'S1': (context) => Screen1(
      //         title: 'Gallery',
      //       ),
      //   'S2': (context) => Screen2(title: 'Payment'),
      // },
    ),
  );
}
